package superMarketPrice.business;

import java.util.List;

import superMarketPrice.model.Product;
import superMarketPrice.model.Cart;
import superMarketPrice.model.Discount;
import superMarketPrice.model.Item;
import superMarketPrice.model.Price;

public class AmountForPriceDiscount implements Discount {

	private final Product product;
	private final int amount;
	private final Price price;

	public AmountForPriceDiscount(Product product, int amount, Price price) {
		this.product = product;
		this.amount = amount;
		this.price = price;
	}


	public double discount(Cart cart) {
		int numberOfItems = 0;
		List<Item> allItems = cart.getItemsByArticle(product);
		for (Item item : allItems) {
			numberOfItems += item.getAmount();
		}
		double discount = product.total(numberOfItems) - price.total(numberOfItems / amount);
		return discount;
	}

}
