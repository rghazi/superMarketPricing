package superMarketPrice.business;

import superMarketPrice.model.Product;
import superMarketPrice.model.Cart;
import superMarketPrice.model.Discount;
import superMarketPrice.model.Item;

public class XForYDiscount implements Discount {

	private final Product product;
	private final double itemAmount;
	private final double forAmount;

	public XForYDiscount(Product product, double xAmount, double yAmount) {
		this.product = product;
		this.itemAmount = xAmount;
		this.forAmount = yAmount;
	}

public double discount(Cart cart) {
		int amount = 0;
		for (Item item : cart.getItemsByArticle(product)) {
			amount += item.getAmount();
		}
		double discount = (amount / itemAmount) * product.total(itemAmount - forAmount);
		return discount;
	}

}
