package superMarketPrice.model;

public class Item {

	private final Product product;
	private final double amount;

	public Item(Product product, double amount) {
		this.product = product;
		this.amount = amount;
	}

	public double total() {
		return product.total(amount);
	}

	public double getAmount() {
		return amount;
	}

	public boolean isArticle(Product product) {
		return this.product.equals(product);
	}

}
