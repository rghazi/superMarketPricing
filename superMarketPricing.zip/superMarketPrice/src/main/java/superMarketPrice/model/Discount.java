package superMarketPrice.model;

@FunctionalInterface
public interface Discount {

	double discount(Cart cart);

}