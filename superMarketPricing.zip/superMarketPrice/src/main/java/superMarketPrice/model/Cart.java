package superMarketPrice.model;

import java.util.ArrayList;

import java.util.List;

public class Cart {

	private List<Item> items = new ArrayList<Item>();
	
	public void add(Item item) {
		items.add(item);
	}

	public double total() {
		double total = 0.0;
		for (Item item : items) {
			total += item.total();
		}
		return total;
	}
	
	public List<Item> getItemsByArticle(Product product) {
		List<Item> productItems = new ArrayList<Item>();
		for (Item item : items) {
			if (item.isArticle(product)) {
				productItems.add(item);
			}
		}
		return productItems;
	}

}
