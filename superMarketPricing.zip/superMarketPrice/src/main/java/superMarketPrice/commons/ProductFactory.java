package superMarketPrice.commons;

import superMarketPrice.model.Product;
import superMarketPrice.model.Price;

public class ProductFactory {

	private int nextId = 0;

	public Product product(double price) {
		nextId += 1;
		return new Product(nextId, new Price(price));
	}
	
}
