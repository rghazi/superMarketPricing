package superMarketPrice.commons;

import superMarketPrice.model.Product;
import superMarketPrice.model.Item;

public class ItemBuilder {

	public ItemSpecifier create(Product product) {
		return new ItemSpecifier(product);
	}

	public static class ItemSpecifier {
		private Product product;
		private double amount;
		
		public ItemSpecifier(Product product) {
			this.product = product;
		}

		public ItemSpecifier amount(int amount) {
			this.amount = amount;
			return this;
		}

		public Item item() {
			return new Item(product, amount);
		}
		
	}
}
