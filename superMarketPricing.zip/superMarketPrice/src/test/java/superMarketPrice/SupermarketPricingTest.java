package superMarketPrice;

import org.junit.Test;

import junit.framework.Assert;
import superMarketPrice.business.AmountForPriceDiscount;
import superMarketPrice.business.Cassier;
import superMarketPrice.business.XForYDiscount;
import superMarketPrice.commons.ItemBuilder;
import superMarketPrice.commons.ProductFactory;
import superMarketPrice.model.Cart;
import superMarketPrice.model.Price;
import superMarketPrice.model.Product;



public class SupermarketPricingTest {
	 
	private ProductFactory productFactory = new ProductFactory();
	private Product product0 = productFactory.product(1.0);
	private Product product1 = productFactory.product(1.5);
	private ItemBuilder itemBuilder = new ItemBuilder();
    
	@Test
	public void testNoItems() {
		System.out.println("testNoItems -->");
		Cassier cassier = new Cassier();
		Cart cart = new Cart();
		double total = cassier.total(cart);		
		Assert.assertEquals(0.0, total, 0.001);
		
	}

	@Test
	public void testOneItem() {
		Cassier cassier = new Cassier();
		Cart cart = new Cart();
		cart.add(itemBuilder.create(product0).amount(1).item());
		double total = cassier.total(cart);		
		Assert.assertEquals(1.0, total, 0.001);
	}

	@Test
	public void testItems() {
		Cassier cassier = new Cassier();
		Cart cart = new Cart();
		cart.add(itemBuilder.create(product0).amount(1).item());
		cart.add(itemBuilder.create(product1).amount(2).item());
		double total = cassier.total(cart);		
		Assert.assertEquals(4.0, total, 0.001);
	}

	@Test
	public void test3For2() {
		Cassier cassier = new Cassier();
		cassier.addDiscount(new XForYDiscount(product1, 3, 2));
		Cart cart = new Cart();
		cart.add(itemBuilder.create(product0).amount(1).item());
		cart.add(itemBuilder.create(product1).amount(3).item());
		double total = cassier.total(cart);		
		Assert.assertEquals(4.0, total, 0.001);
	}

	@Test
	public void test3ForPrice() {
		Cassier cassier = new Cassier();
		cassier.addDiscount(new AmountForPriceDiscount(product1, 3, new Price(2.5)));
		Cart cart = new Cart();
		cart.add(itemBuilder.create(product0).amount(1).item());
		cart.add(itemBuilder.create(product1).amount(3).item());
		double total = cassier.total(cart);
		System.out.println("test3ForPrice -->"+total);
		Assert.assertEquals(3.5, total, 0.001);
	}
}
